package ex2;

import java.util.Scanner;

public class Teste {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Shape shape = new Shape(10);
        TwoDimensionalShape bds = new TwoDimensionalShape(10, 10);
        Circle circle = new Circle(0, 0, 10);
        Square square = new Square(0, 0, 10);
        Triangle triangle = new Triangle(0, 0, 10);
        ThreeDimensionalShape tds = new ThreeDimensionalShape(10, 10, 10);
        Sphere sphere = new Sphere(0, 0, 0, 10);
        Cube cube = new Cube(0, 0, 0, 10);
        Tetrahedron tetrahedron = new Tetrahedron(0, 0, 0, 10);

        System.out.printf("Shape -> Double(Width: %.2f); Int(Width: %d)", shape.getComprimento(), (int)Math.round(shape.getComprimento()));
        System.out.printf("\nTwoDimensionalShape -> Double(Comprimento: %.2f, Altura: %.2f); Int(Comprimento: %d, Altura: %d)", bds.getComprimento(), bds.getAltura(), (int)Math.round(bds.getComprimento()), (int)Math.round(bds.getAltura()));
        System.out.printf("\nCircle -> Double(Raio: %.2f, Area: %.2f, Perimetro: %.2f); Int(Raio: %d, Area: %d, Perimetro: %d)", circle.getRaio(), circle.cArea(circle.getRaio()), circle.cPerimetro(circle.getRaio()), (int)Math.round(circle.getRaio()), circle.cAi(circle.getRaio()), circle.cPi(circle.getRaio()));
        System.out.printf("\nSquare -> Double(Lado: %.2f, Area: %.2f, Perimetro: %.2f); Int(Lado: %d, Area: %d, Perimetro: %d)", square.getLado(), square.cArea(square.getLado()), square.cPerimetro(square.getLado()), (int)Math.round(square.getLado()), square.cAi(square.getLado()), square.cPi(square.getLado()));
        System.out.printf("\nTriangle -> Double(Area: %.2f, Perimetro: %.2f); Int(Area: %d, Perimetro: %d)", triangle.cArea(triangle.getBase(), triangle.getAltura()), triangle.cPerimetro(triangle.getBase()), triangle.cAi(triangle.getBase(), triangle.getAltura()), triangle.cPi(triangle.getBase()));
        System.out.printf("\nThreeDimensionalShape -> Double(Comprimento: %.2f, Altura: %.2f, Largura: %.2f); Int(Comprimento: %d, Altura: %d, Largura: %d)", tds.getComprimento(), tds.getAltura(), tds.getLargura(), (int)Math.round(tds.getComprimento()), (int)Math.round(tds.getAltura()), (int)Math.round(tds.getLargura()));
        System.out.printf("\nSphere -> Double(Raio: %.2f, AreadasFaces: %.2f, Volume: %.2f); Int(Radius: %d, AreadasFaces: %d, Volume: %d)", sphere.getRaio(), sphere.cAdasFaces(sphere.getRaio()), sphere.cVolume(sphere.getRaio()), (int)Math.round(sphere.getRaio()), sphere.cAdFi(sphere.getRaio()), sphere.cVi(sphere.getRaio()));
        System.out.printf("\nCube -> Double(Lado: %.2f, AreadasFaces: %.2f, Volume: %.2f); Int(Lado: %d, AreadasFaces: %d, Volume: %d)", cube.getLado(), cube.cAdasFaces(cube.getLado()), cube.cVolume(cube.getLado()), (int)Math.round(cube.getLado()), cube.cAdFi(cube.getLado()), cube.cVi(cube.getLado()));
        System.out.printf("\nTetrahedron -> Double(AreadasFaces: %.2f, Volume: %.2f); Int(AreadasFaces: %d, Volume: %d)", tetrahedron.cAdasFaces(tetrahedron.getBase()), tetrahedron.cVolume(tetrahedron.getBase()), tetrahedron.cAdFi(tetrahedron.getBase()), tetrahedron.cVi(tetrahedron.getBase()));

        System.out.print("Insira um comprimento: ");
        int ex = Integer.parseInt(sc.nextLine());
        shape.setComprimento(ex);
        System.out.print("Insira um comprimento: ");
        ex = Integer.parseInt(sc.nextLine());
        System.out.print("Insira uma altura: ");
        double ex1 = Double.parseDouble(sc.nextLine());
        bds.setComprimento(ex);
        bds.setAltura(ex1);
        System.out.print("Insira um raio: ");
        ex1 = Double.parseDouble(sc.nextLine());
        circle.setRaio(ex1);
        System.out.print("Insira um lado: ");
        ex1 = Double.parseDouble(sc.nextLine());
        square.setLado(ex1);
        System.out.print("Insira uma base: ");
        ex1 = Double.parseDouble(sc.nextLine());
        triangle.setBase(ex1);
        System.out.print("Insira um comprimento: ");
        ex1 = Double.parseDouble(sc.nextLine());
        tds.setComprimento(ex1);
        System.out.print("Insira uma altura: ");
        ex1 = Double.parseDouble(sc.nextLine());
        tds.setAltura(ex1);
        System.out.print("Insira uma largura: ");
        ex1 = Double.parseDouble(sc.nextLine());
        tds.setLargura(ex1);
        System.out.print("Insira um raio: ");
        ex1 = Double.parseDouble(sc.nextLine());
        sphere.setRaio(ex1);
        System.out.print("Insira um lado: ");
        ex1 = Double.parseDouble(sc.nextLine());
        cube.setLado(ex1);
        System.out.print("Insira uma base: ");
        ex1 = Double.parseDouble(sc.nextLine());
        tetrahedron.setBase(ex1);

        System.out.printf("Shape -> Double(Width: %.2f); Int(Width: %d)", shape.getComprimento(), (int)Math.round(shape.getComprimento()));
        System.out.printf("\nTwoDimensionalShape -> Double(Comprimento: %.2f, Altura: %.2f); Int(Comprimento: %d, Altura: %d)", bds.getComprimento(), bds.getAltura(), (int)Math.round(bds.getComprimento()), (int)Math.round(bds.getAltura()));
        System.out.printf("\nCircle -> Double(Raio: %.2f, Area: %.2f, Perimetro: %.2f); Int(Raio: %d, Area: %d, Perimetro: %d)", circle.getRaio(), circle.cArea(circle.getRaio()), circle.cPerimetro(circle.getRaio()), (int)Math.round(circle.getRaio()), circle.cAi(circle.getRaio()), circle.cPi(circle.getRaio()));
        System.out.printf("\nSquare -> Double(Lado: %.2f, Area: %.2f, Perimetro: %.2f); Int(Lado: %d, Area: %d, Perimetro: %d)", square.getLado(), square.cArea(square.getLado()), square.cPerimetro(square.getLado()), (int)Math.round(square.getLado()), square.cAi(square.getLado()), square.cPi(square.getLado()));
        System.out.printf("\nTriangle -> Double(Area: %.2f, Perimetro: %.2f); Int(Area: %d, Perimetro: %d)", triangle.cArea(triangle.getBase(), triangle.getAltura()), triangle.cPerimetro(triangle.getBase()), triangle.cAi(triangle.getBase(), triangle.getAltura()), triangle.cPi(triangle.getBase()));
        System.out.printf("\nThreeDimensionalShape -> Double(Comprimento: %.2f, Altura: %.2f, Largura: %.2f); Int(Comprimento: %d, Altura: %d, Largura: %d)", tds.getComprimento(), tds.getAltura(), tds.getLargura(), (int)Math.round(tds.getComprimento()), (int)Math.round(tds.getAltura()), (int)Math.round(tds.getLargura()));
        System.out.printf("\nSphere -> Double(Raio: %.2f, AreadasFaces: %.2f, Volume: %.2f); Int(Radius: %d, AreadasFaces: %d, Volume: %d)", sphere.getRaio(), sphere.cAdasFaces(sphere.getRaio()), sphere.cVolume(sphere.getRaio()), (int)Math.round(sphere.getRaio()), sphere.cAdFi(sphere.getRaio()), sphere.cVi(sphere.getRaio()));
        System.out.printf("\nCube -> Double(Lado: %.2f, AreadasFaces: %.2f, Volume: %.2f); Int(Lado: %d, AreadasFaces: %d, Volume: %d)", cube.getLado(), cube.cAdasFaces(cube.getLado()), cube.cVolume(cube.getLado()), (int)Math.round(cube.getLado()), cube.cAdFi(cube.getLado()), cube.cVi(cube.getLado()));
        System.out.printf("\nTetrahedron -> Double(AreadasFaces: %.2f, Volume: %.2f); Int(AreadasFaces: %d, Volume: %d)", tetrahedron.cAdasFaces(tetrahedron.getBase()), tetrahedron.cVolume(tetrahedron.getBase()), tetrahedron.cAdFi(tetrahedron.getBase()), tetrahedron.cVi(tetrahedron.getBase()));

        sc.close();
        }
    }

