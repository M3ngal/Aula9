package ex2;

public class Circle extends TwoDimensionalShape {
    private double raio;

    public Circle(double comprimento, double altura, double raio){
        super(comprimento, altura);
        this.raio = raio;
    }

    public double getRaio(){
        return raio;
    }

    public void setRaio(double raio){
        this.raio = raio;
    }

    public double cArea(double raio){
        return Math.pow(raio,2) * Math.PI;
    }

    public double cPerimetro(double raio){
        return 2 * Math.PI * raio;
    }

    public int cAi(double raio){
        return (int)Math.round(cArea(raio));
    }

    public int cPi(double raio){
        return (int)Math.round(cPerimetro(raio));
    }
}
