package ex2;

public class Tetrahedron extends ThreeDimensionalShape{
    private double base;

    public Tetrahedron(double comprimento, double altura, double largura, double base){
        super(comprimento, altura, largura);
        this.base = base;
    }

    public double getBase(){
        return base;
    }

    public void setBase(double base){
        this.base = base;
    }

    public double cVolume(double base){
        return (base * Math.sqrt(2))/12;
    }

    public double cAdasFaces(double base){
        return Math.sqrt(3) * Math.pow(base,2);
    }

    public int cVi(double base){
        return (int)Math.round(cVolume(base));
    }

    public int cAdFi(double base){
        return (int)Math.round(cAdasFaces(base));
    }
}
