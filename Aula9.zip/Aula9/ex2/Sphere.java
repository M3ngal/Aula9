package ex2;

public class Sphere extends ThreeDimensionalShape{
    private double raio;

    public Sphere(double comprimento, double altura,double largura, double raio){
        super(comprimento, altura, largura);
        this.raio = raio;
    }

    public double getRaio(){
        return raio;
    }

    public void setRaio(double raio){
        this.raio = raio;
    }

    public double cVolume(double raio){
        return (4.0/3.0) * Math.PI * Math.pow(raio,3);
    }

    public double cAdasFaces(double raio){
        return 4 * Math.PI * Math.pow(raio,2);
    }

    public int cVi(double raio){
        return (int)Math.round(cVolume(raio));
    }

    public int cAdFi(double raio){
        return (int)Math.round(cAdasFaces(raio));
    }
}
