package ex2;

public class TwoDimensionalShape extends Shape {
    private double altura;

    public TwoDimensionalShape(double comprimento, double altura){
        super(comprimento);
        this.altura = altura;
    }

    public double getAltura(){
        return altura;
    }

    public void setAltura(double altura){
        this.altura = altura;
    }
}
