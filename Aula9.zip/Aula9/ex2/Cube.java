package ex2;

public class Cube extends ThreeDimensionalShape{
    private double lado;

    public Cube(double comprimento, double altura, double largura, double lado){
        super(comprimento, altura, largura);
        this.lado = lado;
    }

    public double getLado(){
        return lado;
    }

    public void setLado(double lado){
        this.lado = lado;
    }

    public double cVolume(double lado){
        return Math.pow(lado,3);
    }

    public double cAdasFaces(double lado){
        return 6 * Math.pow(lado,2);
    }

    public int cVi(double lado){
        return (int)Math.round(cVolume(lado));
    }

    public int cAdFi(double lado){
        return (int)Math.round(cAdasFaces(lado));
    }
}
