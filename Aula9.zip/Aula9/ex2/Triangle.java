package ex2;

public class Triangle extends TwoDimensionalShape {
    private double base;

    public Triangle(double comprimento, double altura, double base){
        super(comprimento, altura);
        this.base = base;
    }

    public double getBase(){
        return base;
    }

    public void setBase(double base){
        this.base = base;
    }

    public double cArea(double altura, double base){
        return (base * altura)/2;
    }

    public double cPerimetro(double base){
        return base * 3;
    }

    public int cAi(double altura, double base){
        return (int)Math.round(cArea(altura, base));
    }

    public int cPi(double base){
        return (int)Math.round(cPerimetro(base));
    }
}
