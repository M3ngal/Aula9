package ex2;

public class Square extends TwoDimensionalShape {
    private double lado;

    public Square(double comprimento, double altura, double lado){
        super(comprimento, altura);
        this.lado = lado;
    }

    public double getLado(){
        return lado;
    }

    public void setLado(double lado){
        this.lado = lado;
    }

    public double cArea(double lado){
        return Math.pow(lado,2);
    }

    public double cPerimetro(double lado){
        return 4 * lado;
    }

    public int cAi(double lado){
        return (int)Math.round(cArea(lado));
    }

    public int cPi(double lado){
        return (int)Math.round(cPerimetro(lado));
    }
}
