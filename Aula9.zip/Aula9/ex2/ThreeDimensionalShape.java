package ex2;

public class ThreeDimensionalShape extends TwoDimensionalShape{
    private double largura;

    public ThreeDimensionalShape(double comprimento, double altura, double largura){
        super(comprimento, altura);
        this.largura = largura;
    }

    public double getLargura(){
        return largura;
    }

    public void setLargura(double altura){
        this.largura = largura;
    }
}
