package ex2;

public class Shape {
    private double comprimento;

    public Shape(double comprimento){
        this.comprimento = comprimento;
    }

    public double getComprimento(){
        return comprimento;
    }

    public void setComprimento(double comprimento){
        this.comprimento = comprimento;
    }
}
