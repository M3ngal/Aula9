package ex1;

import java.util.Scanner;

public class Teste {
    public static void main(String [] args){ 
    Scanner sc = new Scanner(System.in);

    Pessoa p = new Pessoa("F",20);
    Funcionario f = new Funcionario("D", 22, 1900.10, "Estagiario");
    FuncionarioAposentado a = new FuncionarioAposentado("C", 63, 7000.14);

    System.out.printf("Nome: %s\nIdade: %d", p.getNome(), p.getIdade());
    System.out.printf("Nome: %s\nIdade: %d\nSalario: %f\nCargo: %s", f.getNome(), f.getIdade(), f.getSalario(), f.getCargo());
    System.out.printf("Nome: %s\nIdade: %d\nAposentadoria: %f", a.getNome(), a.getIdade(), a.getSalarioAposentadoria());

    System.out.print("Insira um nome: ");
    String e = sc.nextLine();
    System.out.print("Insira um nome: ");
    int ex = Integer.parseInt(sc.nextLine());
    
    p.setNome(e);
    p.setIdade(ex);

    System.out.printf("Nome: %s\nIdade: %d", p.getNome(), p.getIdade());

    System.out.print("Insira um nome: ");
    String e1 = sc.nextLine();
    System.out.print("Insira um nome: ");
    int ex1 = Integer.parseInt(sc.nextLine());
    System.out.print("Insira o salario: ");
    double es1 = Double.parseDouble(sc.nextLine());
    System.out.print("Insira o cargo: ");
    String ec1 = sc.nextLine();
    
    f.setNome(e1);
    f.setIdade(ex1);
    f.setSalario(es1);
    f.setCargo(ec1);

    System.out.printf("Nome: %s\nIdade: %d\nSalario: %f\nCargo: %s", f.getNome(), f.getIdade(), f.getSalario(), f.getCargo());

    System.out.print("Insira um nome: ");
    String e2 = sc.nextLine();
    System.out.print("Insira um nome: ");
    int ex2 = Integer.parseInt(sc.nextLine());
    System.out.print("Insira a aposentadoria: ");
    double es2 = Double.parseDouble(sc.nextLine());

    a.setNome(e2);
    a.setIdade(ex2);
    a.setSalarioAposentadoria(es2);

    System.out.printf("Nome: %s\nIdade: %d\nAposentadoria: %f", a.getNome(), a.getIdade(), a.getSalarioAposentadoria());
    
        sc.close();
    }
}
