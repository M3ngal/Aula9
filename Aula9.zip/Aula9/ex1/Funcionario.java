package ex1;

public class Funcionario extends Pessoa {
    private double salario;
    private String cargo;

    public Funcionario(String nome, int idade, double salario, String cargo){
        super(nome, idade);
        this.salario = salario;
        this.cargo = cargo;
    }

    public double getSalario(){
        return salario;
    }
    public String getCargo(){
        return cargo;
    }

    public void setSalario(double salario){
        this.salario = salario;
    }
    public void setCargo(String cargo){
        this.cargo = cargo;
    }

    public int categoria(){
        if(getIdade() > 20){
            return 30;
        }
        else{
            return 10;
        }
    }

}
