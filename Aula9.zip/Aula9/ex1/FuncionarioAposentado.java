package ex1;

public class FuncionarioAposentado extends Pessoa {
    private double salarioAposentadoria;

    public FuncionarioAposentado(String nome, int idade, double salarioAposentadoria){
        super(nome, idade);
        this.salarioAposentadoria = salarioAposentadoria;
    }

    public double getSalarioAposentadoria(){
        return salarioAposentadoria;
    }

    public void setSalarioAposentadoria(double salarioAposentadoria){
        this.salarioAposentadoria = salarioAposentadoria;
    }
}
