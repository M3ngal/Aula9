package ex4;

import javax.swing.*;
import java.util.ArrayList;

public class Deposito {
    public ArrayList<Caixa> registro = new ArrayList<Caixa>();

    public Deposito(ArrayList<Caixa> registro){
        this.registro = registro;
    }

    public void aCaixa(String c, int po, double pe, String d){
        Caixa caixa = new Caixa(c, po, pe, d);
        registro.add(caixa);
    }

    public void rCaixa(String d) {
        for (int i = 0; i < registro.size(); i++) {
            Caixa caixa = registro.get(i);
            if (caixa.getDono().equals(d)) {
                registro.remove(i);
                break;
            }
        }
    }

    public int eCaixa(String d){
        int ce = -1;
        for (int i = 0; i < registro.size(); i++) {
            Caixa caixa = registro.get(i);
            if (caixa.getDono().equals(d)) {
                ce = i;
                break;
            }
        }
        return ce;
    }

    public void mCaixa(String c, int po, String d){
        for (int i = 0; i < registro.size(); i++) {
            Caixa caixa = registro.get(i);
            if (caixa.getDono().equals(d)) {
                caixa.setCorredor(c);
                caixa.setPosicao(po);
                registro.set(i, caixa);
                break;
            }
        }
    }

    public Caixa[] fCaixa(double pe){
        Caixa[] c = new Caixa[registro.size()];
        for(int i = 0; i < registro.size(); i++){
            Caixa caixa = registro.get(i);
            if(caixa.getPeso() > pe){
                c[i] = caixa;
            }
        }
        return c;
    }

    public void iCaixa(Caixa caixa){
        JOptionPane.showMessageDialog(null,"Caixa no corredor: " + caixa.getCorredor() + "\n" + "Posicao da caixa: " + caixa.getPosicao() + "\n" + "Peso da caixa: " + caixa.getPeso() + "\n" + "Dono da caixa: " + caixa.getDono() + "\n");
    }

}
