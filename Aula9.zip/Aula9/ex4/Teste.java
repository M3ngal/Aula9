package ex4;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Teste {
    public static void main(String[] args){
        boolean c = true;
        ArrayList<Caixa> registro = new ArrayList<Caixa>();
        Deposito deposito = new Deposito(registro);

        while (c){
            String co;
            String d;
            int po;
            double pe;
            int m = 0;
            m = Integer.parseInt(JOptionPane.showInputDialog("1. Adiciona caixa\n" + "2. Remove caixa\n" + "3. Procura caixa\n" + "4. Muda caixa\n" + "5. Filtro de caixas\n" + "6. sair"));
            switch (m){
                case 1:
                co = JOptionPane.showInputDialog("Corredor da caixa: ");
                po = Integer.parseInt(JOptionPane.showInputDialog("Posição da caixa: "));
                pe = Double.parseDouble(JOptionPane.showInputDialog("Peso da caixa: "));
                d = JOptionPane.showInputDialog("Dono da caixa: ");
                deposito.aCaixa(co, po, pe, d);
                    break;
                case 2:
                    d = JOptionPane.showInputDialog("Dono da caixa: ");
                    deposito.rCaixa(d);
                    break;
                case 3:
                    d = JOptionPane.showInputDialog("Dono da caixa: ");
                    int ch = deposito.eCaixa(d);
                    if(ch == -1){
                        JOptionPane.showMessageDialog(null,"Caixa não encontrada");
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"Caixa no indice: " + ch);
                    }
                    break;
                case 4:
                    d = JOptionPane.showInputDialog("Dono da caixa: ");
                    co = JOptionPane.showInputDialog("Corredor da caixa: ");
                    po = Integer.parseInt(JOptionPane.showInputDialog("Posição da caixa: "));
                    deposito.mCaixa(co, po ,d);
                    break;
                case 5:
                    pe = Double.parseDouble(JOptionPane.showInputDialog("Peso filtro: "));
                    Caixa[] ce = deposito.fCaixa(pe);
                    for (Caixa t : ce) {
                        deposito.iCaixa(t);
                    }
                    break;
                default :
                c = false;
                break;

            }
        }



    }
}
