package ex5;

import ex3.BlocoDeNotas;
import ex4.Caixa;

import java.util.ArrayList;
import java.util.Scanner;

public class CadastroApp {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        boolean c = true;
        ArrayList<Cliente> banco = new ArrayList<Cliente>();
        BancoDeClientes b = new BancoDeClientes(banco);
        while(c){
            System.out.print("1) Insira um cliente\n");
            System.out.print("2) Remova um cliente\n");
            System.out.print("3) Altere um cliente\n");
            System.out.print("4) Informacoes de um cliente\n");
            System.out.print("5) Listar todas os clientes\n");
            System.out.print("6) Sair do sistema\n");
            int ex = Integer.parseInt(sc.nextLine());

            switch(ex){
                case 1:
                    System.out.print("Insira as informações do cliente (em linas separadas): ");
                    b.aCliente();
                    break;
                case 2:
                    System.out.print("Selecione o id do cliente a ser removido: ");
                    b.rCliente();
                    break;
                case 3:
                    System.out.print("Insira o nome do cliente, seu fone e seu id (em linas separadas):\n");
                    b.alCliente();
                    break;
                case 4:
                    System.out.print("Insira o id do cliente:\n");
                    int id = Integer.parseInt(sc.nextLine());
                    b.iCliente(id);
                    break;
                case 5:
                    b.lCliente();
                    break;
                default:
                    c = false;
            }
        }
        sc.close();
    }
}
