package ex5;

import java.util.Scanner;
import java.util.ArrayList;

public class BancoDeClientes {
    public Scanner sc = new Scanner(System.in);
    public ArrayList<Cliente> banco;


    public BancoDeClientes(ArrayList<Cliente> banco){
        this.banco = banco;
    }

    public void aCliente(){
        String n = sc.nextLine(), f = sc.nextLine(), ids = sc.nextLine();
        int id = Integer.parseInt(ids);
        Cliente cliente = new Cliente(n, f, id);
        banco.add(cliente);
    }

    public void rCliente(){
        int id = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < banco.size(); i++) {
            Cliente cliente = banco.get(i);
            if (cliente.getId() == id) {
                banco.remove(i);
                break;
            }
        }
    }

    public void alCliente() {
        String n = sc.nextLine(), f = sc.nextLine(), ids = sc.nextLine();
        int id = Integer.parseInt(ids);
        Cliente cliente = new Cliente(n, f, id);
        for (int i = 0; i < banco.size(); i++) {
            if (banco.get(i).getId() == id) {
                banco.set(i, cliente);
                System.out.println("Cliente atualizado");
                return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }

    public void iCliente(int id) {
        Cliente cliente;
        for (int i = 0; i < banco.size(); i++) {
            cliente = banco.get(i);
            if (cliente.getId() == id) {
                System.out.println("Nome do cliente: " + cliente.getNome() + "\n" + "Fone do cliente: " + cliente.getFone() + "\n" + "ID do cliente: " + cliente.getId() + "\n");
            return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }

    public void lCliente() {
        Cliente cliente;
        for (int i = 0; i < banco.size(); i++) {
            cliente = banco.get(i);
            System.out.println("Nome do cliente: " + cliente.getNome() + "\n" + "Fone do cliente: " + cliente.getFone() + "\n" + "ID do cliente: " + cliente.getId() + "\n");
        }
    }
}
