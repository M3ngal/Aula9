package ex3;

import java.util.Scanner;
import java.util.ArrayList;

public class BlocoDeNotas {
    public Scanner sc = new Scanner(System.in);
    public ArrayList<String> lista = new ArrayList<String>();

    public BlocoDeNotas(ArrayList<String> lista){
        this.lista = lista;
    }

    public void aNota(){
        String nota = sc.nextLine();
        lista.add(nota);
    }

    public void rNota(){
        int ex = Integer.parseInt(sc.nextLine());
        lista.remove(ex);
    }

    public void mNota(){
        String note = sc.nextLine(), newNote = sc.nextLine();
        lista.set(lista.indexOf(note), newNote);
    }

    public void iNota(){
        System.out.println("Notas: ");
        for (String s : lista) {
            System.out.println(s);
        }
    }
}
