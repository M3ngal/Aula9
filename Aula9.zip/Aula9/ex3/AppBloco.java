package ex3;

import java.util.Scanner;
import java.util.ArrayList;

public class AppBloco {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        boolean c = true;
        ArrayList<String> lista = new ArrayList<String>();
        BlocoDeNotas b = new BlocoDeNotas(lista);
        while(c){
            System.out.print("1) Insira uma nota\n");
            System.out.print("2) Remova uma nota\n");
            System.out.print("3) Altere uma nota\n");
            System.out.print("4) Listar todas as notas\n");
            System.out.print("5) Saia do sistema\n");

            int ex = Integer.parseInt(sc.nextLine());

            switch(ex){
                case 1:
                    System.out.print("Insira uma nota: ");
                    b.aNota();
                    break;
                case 2:
                    System.out.print("Selecione a nota a ser removida: ");
                    b.rNota();
                    break;
                case 3:
                    System.out.print("Insira a nota a ser modificada e a nova nota (em linas separadas):\n");
                    b.mNota();
                    break;
                case 4:
                    b.iNota();
                    break;
                default:
                    c = false;
            }
        }
        sc.close();
    }
}
